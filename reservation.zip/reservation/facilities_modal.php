<div id="facilities" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
	  <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h4 class="modal-title center"><i class = "fa fa-pagelines green"></i>Terms And Condition</h4>
        </div>
         <div class="modal-body">
                <div class="padd">
					<p> 1. Catering is available within the area of Cavite and nearby cities.</p>

					<p>2. Customer must pay 50% of the actual price as an advance payment 3 days after confirmation, if the costumer failed to pay the said advance payment reservation will be cancelled.</p>

					<p>3. The management will call the customer about the payment details.</p>

					<p>4. If the customer wants to cancel its confirmed reservation due to personal reason, the management will get 25% from the advance payment he/she made as charge for the damages.</p>

					<p>5. 50 percent should be paid before the approval of reservation, 3 days without payments will resolve to the termination of reservation.</p>

					<p>6. Terms of payments will be via Padala Center, Cebuana, Palawan Center, or personal payments.</p>
				</div>
        </div>
        
    </div>
</div>