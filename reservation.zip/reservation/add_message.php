<?php
include 'includes/dbcon.php';
	$fullname = $_POST['fullname'];
	$email = $_POST['email'];
	$subject = $_POST['subject'];
	$message = $_POST['message'];
	$date = date("Y-m-d H:i:s");
	
	
		mysqli_query($con,"INSERT INTO message(fullname,email,subject,message,date) 
			VALUES('$fullname','$email','$subject','$message','$date')")or die(mysqli_error());  
	echo "<script>alert('Message has been successfully sent. Thank you for your cooperation.');</script>";
			echo "<script>document.location='contact.php'</script>";  	
?>
