<div class="navbar navbar-fixed-top bs-docs-nav" role="banner">
	<div class="conjtainer">
      <!-- Menu button for smallar screens -->
      <div class="navbar-header">
		  <button class="navbar-toggle btn-navbar" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">
			
		  </button>
		  <!-- Site name for smallar screens -->
		  
		</div>
		<!-- Navigation starts -->
      <nav class="collapse navbar-collapse bs-navbar-collapse" role="navigation">  
	  <ul class="nav navbar-nav">  
          <!-- Upload to server link. Class "dropdown-big" creates big dropdown 
      

          <!-- Upload to server link. Class "dropdown-big" creates big dropdown -->
          <li class="dropdown dropdown-big">
            <a href="https://www.facebook.com/lavorozo"><span class = "label label-info"><i class="fa fa-facebook"></i></span> Like us on Facebook</a>            
          </li>

        </ul>

        <!-- Search form -->
       
        <!-- Links -->
       <!---<ul class="nav navbar-nav pull-right">
         <!--- <li class="dropdown pull-right">            
           <a href="#login" data-toggle="modal">
              <i class="fa fa-user"></i> Log in 
            </a>		        
            <!-- Dropdown menu -->
           <!--- <ul class="dropdown-menu">
              <li><a href="#"><i class="fa fa-user"></i> Profile</a></li>
              <li><a href="#"><i class="fa fa-cogs"></i> Settings</a></li>
              <li><a href="login.html"><i class="fa fa-sign-out"></i> Logout</a></li>
            </ul>
          </li>
          
        </ul>--->
      </nav> 

    </div>
	</div>
	