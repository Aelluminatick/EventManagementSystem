<?php
include('../includes/dbcon.php');

 if (isset($_POST['update']))
 { 
	 $id = $_POST['id'];
	 $category = $_POST['subcategory'];
	 
	 mysqli_query($con,"UPDATE packages SET package_name='$category' where package_id='$id'")
	 or die(mysqli_error($con)); 

		echo "<script type='text/javascript'>alert('Successfully updated!');</script>";
		echo "<script>document.location='eventcategory.php'</script>";
	
} 

