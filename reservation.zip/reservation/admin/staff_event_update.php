<?php
include('../includes/dbcon.php');

 if (isset($_POST['update']))
 { 
	 $id = $_POST['id'];
	 $what = $_POST['what'];
	 $where = $_POST['where'];
	 $date = $_POST['date'];
	 $time = $_POST['time'];
	 
	 
	 mysqli_query($con,"UPDATE staff_event SET staffevent_what='$what',staffevent_where='$where',staffevent_date='$date',staffevent_time='$time' where staffevent_id='$id'")
	 or die(mysqli_error($con)); 

		echo "<script type='text/javascript'>alert('Successfully updated the event details!');</script>";
		echo "<script>document.location='staff_event.php'</script>";
	
} 

