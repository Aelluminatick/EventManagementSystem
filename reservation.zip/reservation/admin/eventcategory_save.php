<?php 

include('../includes/dbcon.php');
	
	$category = $_POST['subcategory'];
	
	$result = mysqli_query($con,"SELECT package_name FROM packages where package_name='$category'"); 
        $count = mysqli_num_rows($result);

        if ($count==0)
        {
        	mysqli_query($con,"INSERT INTO packages(package_name) 
			VALUES('$category')")or die(mysqli_error());  
			echo "<script type='text/javascript'>alert('Successfully added new event!');</script>";
			echo "<script>document.location='eventcategory.php'</script>";   
		}
		else
		{
			echo "<script type='text/javascript'>alert('Event already added!');</script>";
			echo "<script>document.location='eventcategory.php'</script>";   
		}
?>