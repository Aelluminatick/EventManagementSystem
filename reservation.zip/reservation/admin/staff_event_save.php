<?php 

include('../includes/dbcon.php');
	
	$what = $_POST['what'];
	$where = $_POST['where'];
	$time = $_POST['time'];
	$date = $_POST['date'];
	
	
		mysqli_query($con,"INSERT INTO staff_event(staffevent_what,staffevent_where,staffevent_date,staffevent_time) 
			VALUES('$what','$where','$date','$time')")or die(mysqli_error());  
			echo "<script type='text/javascript'>alert('Successfully added a new event!');</script>";
			echo "<script>document.location='staff_event.php'</script>";   
	
	
?>