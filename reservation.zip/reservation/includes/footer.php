<footer>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
            <!-- Copyright info -->
            <p class="copy">Copyright &copy; 2012 | <a href="#">Lavorozo Catering Services</a> </p>
      </div>
    </div>
  </div>
</footer> 